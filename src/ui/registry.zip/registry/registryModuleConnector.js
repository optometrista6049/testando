/*
Monteserin Academy

Registry Module Connector
========================================================
*/

import {

    initializeRegistryContent,

    registerRegistryModule

} from "./registryContentManager.js";

import {

    createInventoryModule

} from "./modules/inventoryModule.js";



//======================================================
// INICIALIZAR
//======================================================

export function initializeRegistryModules(

    registryContent

){

    initializeRegistryContent(

        registryContent

    );

    registerRegistryModule(

        "inventory",

        createInventoryModule()
		
		

    );

}
//======================================================
// CONTENT MANAGER
//======================================================

import {

    showRegistryModule,

    getCurrentRegistryModule

} from "./registryContentManager.js";

//======================================================
// SECCIONES
//======================================================

const registrySectionMap = [

    "inventory",

    "archive",

    "journal",

    "help"

];

//======================================================
// MOSTRAR SECCIÓN
//======================================================

export function showRegistrySection(index){

    if(

        index < 0 ||

        index >= registrySectionMap.length

    ){

        return;

    }

    showRegistryModule(

        registrySectionMap[index]

    );
	
	

}

//======================================================
// OBTENER SECCIÓN ACTIVA
//======================================================

export function getCurrentRegistrySection(){

    return getCurrentRegistryModule();

}