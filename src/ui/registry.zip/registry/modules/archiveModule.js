//--------------------------------------------------
// ARCHIVE MODULE
//--------------------------------------------------

let archiveModule = null;

//--------------------------------------------------
// CREAR
//--------------------------------------------------

export function createArchiveModule(){

    if(archiveModule){

        return archiveModule;

    }

    archiveModule =
        document.createElement("div");

    archiveModule.id =
        "archiveModule";

    archiveModule.className =
        "registryModule";

    //--------------------------------------------------
    // TÍTULO
    //--------------------------------------------------

    const title =
        document.createElement("div");

    title.id =
        "archiveTitle";

    title.textContent =
        "Archivo";

    //--------------------------------------------------
    // CONTENIDO
    //--------------------------------------------------

    const content =
        document.createElement("div");

    content.id =
        "archiveContent";

    content.textContent =
        "Sistema documental en construcción.";

    archiveModule.append(
        title,
        content
    );

    return archiveModule;

}

//--------------------------------------------------
// OBTENER
//--------------------------------------------------

export function getArchiveModule(){

    return archiveModule;

}